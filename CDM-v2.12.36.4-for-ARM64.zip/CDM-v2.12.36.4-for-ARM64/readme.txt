The "install-CDM-v2.12.36.4-for-ARM64.bat" is a script to install necessary files for the FTDI ARM64 driver.
Please run the "install-CDM-v2.12.36.4-for-ARM64.bat" using administrator rights (Right click -> Run as administrator)

GFI System