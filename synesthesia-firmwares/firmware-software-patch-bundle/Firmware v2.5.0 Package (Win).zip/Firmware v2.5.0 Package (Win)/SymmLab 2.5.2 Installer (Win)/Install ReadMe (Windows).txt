Installation Procedures :
-----------------------

1.  Install the SymmLab software --> double click on 'setup'.

2.  Install USB Driver* --> double click on 'CDM21218_Setup.exe'.
       
    *If you have previously installed the driver (when installing previous version of the software,  
    or other software from GFI System) then this step may be skipped.


After completing the above steps you are ready to connect Synesthesia to your computer. Enjoy!
